﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CreditCardWebApi.Migrations
{
    public partial class first : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CreditCards",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    cardName = table.Column<string>(nullable: true),
                    cardType = table.Column<string>(nullable: true),
                    cardNo = table.Column<string>(nullable: true),
                    cardValid = table.Column<string>(nullable: true),
                    cardCvc = table.Column<int>(nullable: false),
                    cardBalance = table.Column<float>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CreditCards", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Transactions",
                columns: table => new
                {
                    transactionId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    userName = table.Column<string>(nullable: true),
                    transactionAmount = table.Column<string>(nullable: true),
                    cardNo = table.Column<string>(nullable: true),
                    cardName = table.Column<string>(nullable: true),
                    cardType = table.Column<string>(nullable: true),
                    cardValid = table.Column<string>(nullable: true),
                    cardCvc = table.Column<int>(nullable: false),
                    transactionDate = table.Column<string>(nullable: true),
                    transactionStatus = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Transactions", x => x.transactionId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CreditCards");

            migrationBuilder.DropTable(
                name: "Transactions");
        }
    }
}
