﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using CreditCardClientApplication.Helper;
using CreditCardClientApplication.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CreditCardClientApplication.Controllers
{
    public class TransactionsController : Controller
    {
        // GET: Transactions
        public ActionResult Index()
        {
            IEnumerable<Transaction> transactions;
            HttpResponseMessage response = GlobalVariables.WebApiClient.GetAsync("Transactions").Result;
            transactions = response.Content.ReadAsAsync<IEnumerable<Transaction>>().Result;
            return View(transactions);
        }

        // GET: Transactions/Details/5
        public ActionResult Details(int id)
        {
            Transaction transactions;
            HttpResponseMessage response = GlobalVariables.WebApiClient.GetAsync("Transactions/"+id.ToString()).Result;
            transactions = response.Content.ReadAsAsync<Transaction>().Result;
            return View(transactions);
        }

        // GET: Transactions/Create
        public ActionResult Create()
        {
            return View(new Transaction());
        }

        // POST: Transactions/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Transaction transaction)
        {
            try
            {
                // TODO: Add insert logic here
                HttpResponseMessage response = GlobalVariables.WebApiClient.PostAsJsonAsync("Transactions", transaction).Result;
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Transactions/Edit/5
        public ActionResult Edit(int id)
        {
            Transaction transactions;
            HttpResponseMessage response = GlobalVariables.WebApiClient.GetAsync("Transactions/" + id.ToString()).Result;
            transactions = response.Content.ReadAsAsync<Transaction>().Result;
            return View(transactions);
        }

        // POST: Transactions/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Transaction transaction)
        {
            try
            {
                // TODO: Add update logic here
                HttpResponseMessage response = GlobalVariables.WebApiClient.PutAsJsonAsync("Transactions"+id.ToString(), transaction).Result;
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Transactions/Delete/5
        public ActionResult Delete(int id)
        {
            Transaction transactions;
            HttpResponseMessage response = GlobalVariables.WebApiClient.GetAsync("Transactions/" + id.ToString()).Result;
            transactions = response.Content.ReadAsAsync<Transaction>().Result;
            return View(transactions);
        }

        // POST: Transactions/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Transaction transaction)
        {
            try
            {
                // TODO: Add delete logic here
                HttpResponseMessage response = GlobalVariables.WebApiClient.DeleteAsync("Transactions"+id.ToString()).Result;
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}