﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using CreditCardClientApplication.Helper;
using CreditCardClientApplication.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CreditCardClientApplication.Controllers
{
    public class CardsController : Controller
    {
        // GET: Cards
        CreditCardApi _api = new CreditCardApi();
        public async Task<IActionResult> Index()
        {
            List<CreditCard> creditCards = new List<CreditCard>();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync("api/CreditCards");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                creditCards = JsonConvert.DeserializeObject<List<CreditCard>>(result);
            }
            return View(creditCards);
        }

        // GET: Cards/Details/5
        public async Task<IActionResult> Details(int id)
        {
            CreditCard creditCards = new CreditCard();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync("api/CreditCards/"+id.ToString());
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                creditCards = JsonConvert.DeserializeObject<CreditCard>(result);
            }
            return View(creditCards);
        }

        // GET: Cards/Create
        public ActionResult Create()
        {
            return View(new CreditCard());
        }

        // POST: Cards/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(CreditCard creditCard)
        {
            try
            {
                // TODO: Add insert logic here

                HttpResponseMessage resonse = GlobalVariables.WebApiClient.PostAsJsonAsync("CreditCards", creditCard).Result;
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Cards/Edit/5
        public async Task<IActionResult> Edit(int id)
        {

            CreditCard creditCards = new CreditCard();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync("api/CreditCards/" + id.ToString());
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                creditCards = JsonConvert.DeserializeObject<CreditCard>(result);
            }
            return View(creditCards);
        }

        // POST: Cards/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, CreditCard creditCard)
        {
            try
            {
                // TODO: Add update logic here
                HttpResponseMessage resonse = GlobalVariables.WebApiClient.PutAsJsonAsync("CreditCards/" + id.ToString(), creditCard).Result;
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Cards/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            CreditCard creditCards = new CreditCard();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync("api/CreditCards/" + id.ToString());
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                creditCards = JsonConvert.DeserializeObject<CreditCard>(result);
            }
            return View(creditCards);
        }

        // POST: Cards/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, CreditCard creditCard)
        {
            try
            {
                // TODO: Add delete logic here
                HttpResponseMessage resonse = GlobalVariables.WebApiClient.DeleteAsync("CreditCards/" + id.ToString()).Result;
                return RedirectToAction(nameof(Index));

            }
            catch
            {
                return View();
            }
        }
    }
}