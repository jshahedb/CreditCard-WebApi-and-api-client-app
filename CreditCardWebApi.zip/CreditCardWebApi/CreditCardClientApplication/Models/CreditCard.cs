﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CreditCardClientApplication.Models
{
    public class CreditCard
    {
        public int Id { get; set; }
        public string cardName { get; set; }
        public string cardType { get; set; }
        public string cardNo { get; set; }
        public string cardValid { get; set; }
        public int cardCvc { get; set; }
        public float cardBalance { get; set; }
        public string cardStatus { get; set; }
    }
}
