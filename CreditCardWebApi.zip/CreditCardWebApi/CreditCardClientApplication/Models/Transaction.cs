﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CreditCardClientApplication.Models
{
    public class Transaction
    {
        public int transactionId { get; set; }
        public string userName { get; set; }
        public string transactionAmount {get; set; }
        public string cardNo { get; set; }
        public string cardName { get; set; }
        public string cardType { get; set; }
        public string cardValid { get; set; }
        public int cardCvc { get; set; }
        public string transactionDate{ get; set; }
        public string transactionStatus { get; set; }

    }
}
